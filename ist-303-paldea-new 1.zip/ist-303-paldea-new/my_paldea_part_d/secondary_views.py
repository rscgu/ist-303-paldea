'''from my_paldea.paldea_app.views import *
import pdfkit
from flask import make_response

#paldea_app = Blueprint('paldea_app', __name__)

@paldea_app.route('/my_paldea_part_d/financial_report_pdf')
@login_required
def financial_report_pdf():
    # Use installed Edge/Chrome in headless mode to print the live page to PDF, with all accordions expanded.
    target_url = url_for('paldea_app.home', _external=True) + '?print=1'

    # Find Edge or Chrome executable
    candidates = [
        shutil.which('msedge'),
        shutil.which('chrome'),
        shutil.which('google-chrome'),
        r'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
        r'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
        r'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        r'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'
    ]
    browser_path = next((p for p in candidates if p and os.path.exists(p)), None)
    if not browser_path:
        return Response(b'Browser not found. Please install Microsoft Edge or Google Chrome.', status=500)

    with tempfile.TemporaryDirectory() as tmpdir:
        output_pdf = os.path.join(tmpdir, 'financial-report.pdf')
        user_data_dir = os.path.join(tmpdir, 'ud')
        os.makedirs(user_data_dir, exist_ok=True)
        # Headless print to PDF. virtual-time-budget helps JS-heavy pages finish rendering.
        cmd = [
            browser_path,
            '--headless=new',
            f'--user-data-dir={user_data_dir}',
            f'--print-to-pdf={output_pdf}',
            '--print-to-pdf-no-header',
            '--disable-gpu',
            '--no-sandbox',
            '--disable-dev-shm-usage',
            '--run-all-compositor-stages-before-draw',
            '--virtual-time-budget=10000',
            target_url
        ]
        try:
            subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
            with open(output_pdf, 'rb') as f:
                pdf_bytes = f.read()
        except subprocess.TimeoutExpired:
            return Response(b'PDF generation timed out.', status=504)
        except subprocess.CalledProcessError as e:
            return Response(f'PDF generation failed: {e.stderr.decode(errors="ignore")}'.encode(), status=500)

    return Response(pdf_bytes, mimetype='application/pdf', headers={'Content-Disposition': 'attachment; filename=financial-report.pdf'})
'''